object Pr1z1 {
  //Задача 1. Найдите последний элемент списка last(List(1, 1, 2, 3, 5, 6))
    def lastBuiltin[A](ls: List[A]): A = ls.last

    def main (args: Array[String]) {
      print(lastBuiltin(List(1, 1, 2, 3, 5, 6)))
    }



}
